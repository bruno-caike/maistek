<section class="rodape1">


    <a href="#">
        <img class="icoContato" src="./img/local.svg">
        <h3>Endereço</H3>
    </a>

    <a href="https://www.instagram.com/ezequiell_es/" class="insta">
        <img class="icoContato" src="./img/insta.svg">
        <H3>Istagram</H3>
    </a>

    <a href="">
        <img class="icoContato" src="./img/phone.svg">
        <H3>Telefone</H3>
    </a>


</section>

<section class="rodape2">
    <p class="direitosr">©2021. Todos os direitos reservados. | Designer by <strong>Ezequiel Santos<strong></strong> </p>
</section>