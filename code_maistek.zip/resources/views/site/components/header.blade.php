<header class="header">
    <div class="container">
        <a href=""><img src="./img/logo.png" alt="Maistek" class="logoSite"></a>
        <nav>
            <ul class="menu">
                <li> <a href="/">HOME</a></li>
                <li> <a href="#">TECNOLOGIAS</a></li>
                <li> <a href="{{ route('allNews.index') }}">NOTÍCIAS</a></li>
                <li> <a href="{{ route('contactUs.index') }}">FALE CONOSCO</a></li>
                <li> <a href="{{ route('login') }}">LOGIN</a></li>
            </ul>
        </nav>
    </div>
</header>