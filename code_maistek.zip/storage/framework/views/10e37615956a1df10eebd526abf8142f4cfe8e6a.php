
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('site.components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="page-secondaries">
    <article class="title-page-secondaries">
        <header class="container">
            <h1><strong><?php echo e($title_menu); ?></strong></h1>
        </header>
    </article>
    <div class="container">
        <div>
            <?php echo $__env->yieldContent('info'); ?>
        </div>
        <div class="quick-access-pages-secondaries">
            <?php echo $__env->make('site.components.quickAccess', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</main>
<?php echo $__env->make('site.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php\www\maistek\resources\views/site/secondary/index.blade.php ENDPATH**/ ?>