<header class="header">
    <div class="container">
        <a href=""><img src="./img/logo.png" alt="Maistek" class="logoSite"></a>
        <nav>
            <ul class="menu">
                <li> <a href="/">HOME</a></li>
                <li> <a href="#">TECNOLOGIAS</a></li>
                <li> <a href="<?php echo e(route('allNews.index')); ?>">NOTÍCIAS</a></li>
                <li> <a href="<?php echo e(route('contactUs.index')); ?>">FALE CONOSCO</a></li>
                <li> <a href="<?php echo e(route('login')); ?>">LOGIN</a></li>
            </ul>
        </nav>
    </div>
</header><?php /**PATH C:\xampp\php\www\maistek\resources\views/site/components/header.blade.php ENDPATH**/ ?>