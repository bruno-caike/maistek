
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('site.components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- SECAO START -->
<section class="sec2">
    <div class="container">
        <header class="header-2">
            <div>
                <h1 class="fraseTopo"><?php echo e(isset($tec->title) ? $tec->title : ''); ?></h1>
                <h5 class="textoTopo">
                    <p>
                        <?php if(isset($tec->contents)): ?>
                            <?php echo strlen(strip_tags($tec->contents)) > 105 ? mb_substr(strip_tags($tec->contents),0,105).' [...]' : strip_tags($tec->contents); ?>

                        <?php endif; ?>
                    </p>
                </H5>

                <a href="<?php echo e(route('informationTechnology.index')); ?>" class="botaoInfo">MAIS INFORMAÇÕES</a>

            </div>

            <img src="img/conputer.png" alt="imagem-copmputador" class="img-computatador">

        </header>
    </div>
</section>

<!-- ACESSO RÁPIDO - START -->
<div class="container">
    <?php echo $__env->make('site.components.quickAccess', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<!-- ACESSO RÁPIDO - END -->

<!-- NOTICIAS - START -->
<div class="container">
    <h2 class="tituloPrincipalNoticia">Principais noticias</h2><br>



    <section class="noticias">
        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <section>
                <a href="<?php echo e(route('new.show', ['id'=>$n->id, 'slug'=>\Str::slug($n->title)])); ?>">
                    <div>
                        <img src="<?php echo e(!empty($new->link_img) ? url('storage/img-news/'.$new->link_img.'') : 'img/sem-img.jpg'); ?>" class="imgNoticia">
                        <p class="ttNoticia"><?php echo e($new->title); ?></p>
                        <p class="resumoNoticia"><?php echo e($new->contents); ?></p>
                    </div>
                </a>
            </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
</div>



<!-- NOTICIAS - END -->

<!-- LINHA DIVISÓRIA NOTICIAS-FORMULARIO - START -->
<section>

    <div id="line"></div>

</section>

<!-- LINHA DIVISÓRIA NOTICIAS-FORMULARIO - END -->

<!-- FALE CONOSCO - START -->
<div class="containerForm">
    <section id="faleCo">Fale Conosco</section>

    <form action="<?php echo e(route('contacts.store')); ?>" method="POST" class="formulario <?php echo e(!empty(session('mensagem')) ? session('mensagem') : ''); ?>">
        <?php echo csrf_field(); ?>
        <div class="grupo">
            <div>
                <div class="campo">

                    <div>
                        <label class="texForm" for="nome">Nome</label>
                        <input type="text" name="name" class="<?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" id="nome" value="<?php echo e(old('name')); ?>" required>
                        <?php if($errors->has('name')): ?>
                            <div class="invalid-feedback"><?php echo e($errors->first('name')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div> <label class="texForm" for="nome">Telefone</label>
                        <input type="text" name="tel" class="telephone <?php echo e($errors->has('tel') ? 'is-invalid' : ''); ?>" id="telefone" value="<?php echo e(old('tel')); ?>" required>
                        <?php if($errors->has('tel')): ?>
                            <div class="invalid-feedback"><?php echo e($errors->first('tel')); ?></div>
                        <?php endif; ?>
                    </div>

                    <div>
                        <label class="texForm" for="nome">E-mail</label>
                        <input type="email" name="email" class="<?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" id="email" value="<?php echo e(old('email')); ?>" required>
                        <?php if($errors->has('email')): ?>
                            <div class="invalid-feedback"><?php echo e($errors->first('email')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div>
                        <label class="texForm" for="nome">Setor</label>
                        <input type="text" name="sector" class="<?php echo e($errors->has('sector') ? 'is-invalid' : ''); ?>" id="setor" value="<?php echo e(old('sector')); ?>" required>
                        <?php if($errors->has('sector')): ?>
                            <div class="invalid-feedback"><?php echo e($errors->first('sector')); ?></div>
                        <?php endif; ?>
                    </div>

                    <div>
                        <label class="texForm" for="Mensagem" class="mensagem">Mensagem</label>
                        <textarea name="message" id="mensagem" rows="10" class="mensagem <?php echo e($errors->has('message') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('message')); ?>" required></textarea>
                        <?php if($errors->has('message')): ?>
                            <div class="invalid-feedback"><?php echo e($errors->first('message')); ?></div>
                        <?php endif; ?>
                    </div>

                </div>
                <div id="bt">
                    <button class="botao" type="submit">ENVIAR</button>
                </div>
            </div>
        </div>
    </form>

</div>
<?php echo $__env->make('site.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php\www\maistek\resources\views/site/main/index.blade.php ENDPATH**/ ?>