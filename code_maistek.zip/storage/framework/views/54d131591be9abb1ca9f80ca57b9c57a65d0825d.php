
<?php $__env->startSection('info'); ?>
<div class="all-news">
    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('new.show', ['id'=>$n->id, 'slug'=>\Str::slug($n->title)])); ?>">
            <article>
                <img src="<?php echo e(!empty($n->link_img) ? url('storage/img-news/'.$n->link_img.'') : 'img/sem-img.jpg'); ?>" class="imgNoticia">
                <header>
                    <span><?php echo e($n->created_at->format('d/m/Y')); ?></span>
                    <h1><strong><?php echo e($n->title); ?></strong></h1>
                    <div><?php echo e($n->contents); ?></div>
                </header>
            </article>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.secondary.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php\www\maistek\resources\views/site/secondary/allNews.blade.php ENDPATH**/ ?>