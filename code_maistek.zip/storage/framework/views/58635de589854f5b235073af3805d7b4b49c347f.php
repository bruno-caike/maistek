
<?php $__env->startSection('info'); ?>
<form action="<?php echo e(route('contactsUs.store')); ?>" method="POST" class="formulario <?php echo e(!empty(session('mensagem')) ? session('mensagem') : ''); ?>">
    <?php echo csrf_field(); ?>
    <div class="grupo">
        <div>
            <div class="campo">

                <div>
                    <label class="texForm" for="nome">Nome</label>
                    <input type="text" name="name" class="<?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" id="nome" value="<?php echo e(old('name')); ?>" required>
                    <?php if($errors->has('name')): ?>
                        <div class="invalid-feedback"><?php echo e($errors->first('name')); ?></div>
                    <?php endif; ?>
                </div>
                <div> <label class="texForm" for="nome">Telefone</label>
                    <input type="text" name="tel" class="telephone <?php echo e($errors->has('tel') ? 'is-invalid' : ''); ?>" id="telefone" value="<?php echo e(old('tel')); ?>" required>
                    <?php if($errors->has('tel')): ?>
                        <div class="invalid-feedback"><?php echo e($errors->first('tel')); ?></div>
                    <?php endif; ?>
                </div>

                <div>
                    <label class="texForm" for="nome">E-mail</label>
                    <input type="email" name="email" class="<?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" id="email" value="<?php echo e(old('email')); ?>" required>
                    <?php if($errors->has('email')): ?>
                        <div class="invalid-feedback"><?php echo e($errors->first('email')); ?></div>
                    <?php endif; ?>
                </div>
                <div>
                    <label class="texForm" for="nome">Setor</label>
                    <input type="text" name="sector" class="<?php echo e($errors->has('sector') ? 'is-invalid' : ''); ?>" id="setor" value="<?php echo e(old('sector')); ?>" required>
                    <?php if($errors->has('sector')): ?>
                        <div class="invalid-feedback"><?php echo e($errors->first('sector')); ?></div>
                    <?php endif; ?>
                </div>

                <div>
                    <label class="texForm" for="Mensagem" class="mensagem">Mensagem</label>
                    <textarea name="message" id="mensagem" rows="10" class="mensagem <?php echo e($errors->has('message') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('message')); ?>" required></textarea>
                    <?php if($errors->has('message')): ?>
                        <div class="invalid-feedback"><?php echo e($errors->first('message')); ?></div>
                    <?php endif; ?>
                </div>

            </div>
            <div id="bt">
                <button class="botao" type="submit">ENVIAR</button>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.secondary.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php\www\maistek\resources\views/site/secondary/contactUs.blade.php ENDPATH**/ ?>