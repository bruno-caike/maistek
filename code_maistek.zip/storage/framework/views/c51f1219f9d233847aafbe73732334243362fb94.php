

<?php $__env->startSection('content'); ?>
<div class="animated fadeIn">
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="card">
                <article class="form-pages list-pages">
                    <header class="mb-3"><h1 class="text-dark"><strong>Cadastro de Noticias</strong></h1></header>
                    <form action="<?php echo e($form == 'edit' ? route('news.update', [$page->id]) : route('news.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if($form == 'edit'): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>
                        <div class="form-group">
                            <label for="title">Titulo</label>
                            <input type="text" class="form-control <?php echo e($errors->has('title') ? 'is-invalid' : ''); ?>" name="title" id="title" value="<?php echo e(old('title') != '' ? old('title') : $new->title); ?>" required>
                            <?php if($errors->has('title')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('title')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="link">Link Noticia</label>
                            <input type="text" class="form-control <?php echo e($errors->has('link') ? 'is-invalid' : ''); ?>" name="link" id="link" value="<?php echo e(old('link') != '' ? old('link') : $new->link); ?>" required>
                            <?php if($errors->has('link')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('link')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="contents">Contexto</label>
                            <textarea name="contents" id="contents" cols="30" rows="7" class="form-control <?php echo e($errors->has('contents') ? 'is-invalid' : ''); ?>"><?php echo e(old('contents') != '' ? old('contents') : $new->contents); ?></textarea>
                            <?php if($errors->has('contents')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('contents')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="active">Foto</label>
                            <input type="file" name="link_img" accept="image/png, image/jpeg">
                        </div>
                        <div class="form-group">
                            <label for="active">Status</label>
                            <div class="flex-checks">
                                <label class="c-switch c-switch-pill c-switch-success">
                                    <input type="checkbox" name="active" class="c-switch-input" value="1" <?php echo e(count($errors) != 0 ? (old('active') == null ? '' : 'checked') : ($new->active == 0 && !empty($new->id)  ?  : 'checked')); ?>>
                                    <span class="c-switch-slider"></span>
                                </label>
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="hidden" name="edit_id" value="<?php echo e(old('edit_id') != '' ? old('edit_id') : $new->id); ?>">
                            <button type="submit" class="btn btn-success">Salvar</button>
                        </div>
                    </form>
                </article>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php\www\maistek\resources\views/news/create.blade.php ENDPATH**/ ?>