
<?php $__env->startSection('info'); ?>
<?php if(isset($description->id)): ?>
    <article class="page-sencodary">
        <header>
            <img src="img/img-programacao.jpg" alt="<?php echo e(isset($description->title) ? $description->title : ''); ?>">
            <span><?php echo e(isset($description->created_at) ? $description->created_at->format('d/m/Y') : ''); ?></span>
            <h1><strong><?php echo e(isset($description->title) ? $description->title : ''); ?></strong></h1>
        </header>
        <div><?php echo e(isset($description->contents) ? $description->contents : ''); ?></div>
    </article>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.secondary.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php\www\maistek\resources\views/site/secondary/programming.blade.php ENDPATH**/ ?>