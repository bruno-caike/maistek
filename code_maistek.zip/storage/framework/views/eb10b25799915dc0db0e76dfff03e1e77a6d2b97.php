
<?php $__env->startSection('info'); ?>
<?php if(isset($description->id)): ?>
    <article class="page-sencodary">
        <header class="none">
            <h1><?php echo e(isset($description->title) ? $description->title : ''); ?></h1>
        </header>
        <div><?php echo e(isset($description->contents) ? $description->contents : ''); ?></div>
    </article>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.secondary.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php\www\maistek\resources\views/site/secondary/informationTechnology.blade.php ENDPATH**/ ?>