@extends('base.layout')

@section('content')
@livewire('profile.update-profile-information-form')
@endsection
