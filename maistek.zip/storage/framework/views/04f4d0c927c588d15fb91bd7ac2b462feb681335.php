<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="fade-in">
                <div class="col-sm-6 col-md-2">
                    <!-- <div class="card">
                        <div class="card-body">
                            <div class="text-muted text-right mb-4">
                                <svg class="c-icon c-icon-2xl">
                                    <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-basket"></use>
                                </svg>
                            </div>
                            <div class="text-value-lg">1238</div><small class="text-muted text-uppercase font-weight-bold">Products sold</small>
                            <div class="progress progress-xs mt-3 mb-0">
                                <div class="progress-bar bg-warning" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div> -->
                </div>

                <div class="col-sm-6 col-md-2">
                    <!-- <div class="card">
                        <div class="card-body">
                            <div class="text-muted text-right mb-4">
                                <svg class="c-icon c-icon-2xl">
                                    <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-chart-pie"></use>
                                </svg>
                            </div>
                            <div class="text-value-lg">28%</div><small class="text-muted text-uppercase font-weight-bold">Returning Visitors</small>
                            <div class="progress progress-xs mt-3 mb-0">
                                <div class="progress-bar" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div> -->
                </div>

                <div class="col-sm-6 col-md-2">
                    <!-- <div class="card">
                        <div class="card-body">
                            <div class="text-muted text-right mb-4">
                                <svg class="c-icon c-icon-2xl">
                                    <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-speedometer"></use>
                                </svg>
                            </div>
                            <div class="text-value-lg">5:34:11</div><small class="text-muted text-uppercase font-weight-bold">Avg. Time</small>
                            <div class="progress progress-xs mt-3 mb-0">
                                <div class="progress-bar bg-danger" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div> -->
                    </div>
                </div>

                <div class="col-sm-6 col-md-2">
                    <!-- ß -->
                </div>

            </div>

        <!-- /.row-->

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<!--
    <script src="<?php echo e(asset('js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/coreui-chartjs.bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>" defer></script>-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php\www\maistek\resources\views/base/homepage.blade.php ENDPATH**/ ?>