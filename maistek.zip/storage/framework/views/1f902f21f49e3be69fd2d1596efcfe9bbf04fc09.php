

<?php $__env->startSection('content'); ?>
<div class="animated fadeIn">
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="card">
                <article class="form-pages list-pages">
                    <header class="mb-3"><h1 class="text-dark"><strong>Cadastro de Paginas</strong></h1></header>
                    <form action="<?php echo e($form == 'edit' ? route('pages.update', [$page->id]) : route('pages.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php if($form == 'edit'): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>
                        <div class="row form-group">
                            <div class="col-sm-6 col-12">
                                <label for="menu_page">Menu da pagina</label>
                                <input type="text" class="form-control <?php echo e($errors->has('menu_page') ? 'is-invalid' : ''); ?>" name="menu_page" id="menu_page" value="<?php echo e(old('menu_page') != '' ? old('menu_page') : $page->menu_page); ?>" required>
                                <?php if($errors->has('menu_page')): ?>
                                    <div class="invalid-feedback"><?php echo e($errors->first('menu_page')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="col-sm-6 col-12">
                                <label for="title">Titulo da Pagina</label>
                                <input type="text" class="form-control <?php echo e($errors->has('title') ? 'is-invalid' : ''); ?>" name="title" id="title" value="<?php echo e(old('title') != '' ? old('title') : $page->title); ?>" required>
                                <?php if($errors->has('title')): ?>
                                    <div class="invalid-feedback"><?php echo e($errors->first('title')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="contents">Descrição</label>
                            <textarea name="contents" id="contents" cols="30" rows="7" class="form-control <?php echo e($errors->has('contents') ? 'is-invalid' : ''); ?>"><?php echo e(old('contents') != '' ? old('contents') : $page->contents); ?></textarea>
                            <?php if($errors->has('contents')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('contents')); ?></div>
                            <?php endif; ?>
                        </div>
                
                        <div class="form-group">
                            <label for="active">Status</label>
                            <div class="flex-checks">
                                <label class="c-switch c-switch-pill c-switch-success">
                                    <input type="checkbox" name="active" class="c-switch-input" value="1" <?php echo e(count($errors) != 0 ? (old('active') == null ? '' : 'checked') : ($page->active == 0 && !empty($page->id)  ?  : 'checked')); ?>>
                                    <span class="c-switch-slider"></span>
                                </label>
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="hidden" name="edit_id" value="<?php echo e(old('edit_id') != '' ? old('edit_id') : $page->id); ?>">
                            <button type="submit" class="btn btn-success">Salvar</button>
                        </div>
                    </form>
                </article>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php\www\maistek\resources\views/pages/create.blade.php ENDPATH**/ ?>