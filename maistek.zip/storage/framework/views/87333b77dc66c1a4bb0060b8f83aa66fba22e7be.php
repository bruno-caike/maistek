<a href="/">
    <img src="./img/maistek-marca-02.png" alt="Maistek" class="logoSite" width="250">
</a>
<?php /**PATH C:\xampp\php\www\maistek\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>