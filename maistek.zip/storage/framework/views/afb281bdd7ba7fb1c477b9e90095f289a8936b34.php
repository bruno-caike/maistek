<footer class="c-footer">
  <div><strong><?php echo e(config('app.name', 'Laravel')); ?></strong> &copy;2021 &middot; LABRAS Análises Ambientais e Agrícolas.</div>
  <div class="ml-auto">Feito por&nbsp;<a href="http://doiscomunicacao.com.br">Dois</a></div>
</footer>
<?php /**PATH C:\xampp\php\www\maistek\resources\views/base/shared/footer.blade.php ENDPATH**/ ?>