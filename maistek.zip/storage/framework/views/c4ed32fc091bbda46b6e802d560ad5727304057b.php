<!DOCTYPE html>
<html lang="pt_BR">

<head>
    <base href="http://<?php echo e($_SERVER['HTTP_HOST']); ?>/">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="<?php echo e(URL::asset('/img/fav-icon.png')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/vendor.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/app.css')); ?>">
    <title>Maistek Tecnologia</title>
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body>
    <?php echo $__env->yieldContent('content'); ?>
    <script src="<?php echo e(URL::asset('js/vendor.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('js/app.js')); ?>"></script>
    <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH C:\xampp\php\www\maistek\resources\views/site/layout.blade.php ENDPATH**/ ?>