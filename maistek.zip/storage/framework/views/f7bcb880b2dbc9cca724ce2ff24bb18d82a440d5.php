<div class="c-wrapper">
    <header class="c-header c-header-light c-header-fixed c-header-with-subheader">
        <button class="c-header-toggler c-class-toggler d-lg-none mr-auto" type="button" data-target="#sidebar" data-class="c-sidebar-show"><span class="c-header-toggler-icon"></span></button><a class="c-header-brand d-sm-none" href="#"><img class="c-header-brand" src="<?php echo e(asset('img/logo.png')); ?>" width="97" height="46" alt=""></a>
        <button class="c-header-toggler c-class-toggler ml-3 d-md-down-none" type="button" data-target="#sidebar" data-class="c-sidebar-lg-show" responsive="true"><span class="c-header-toggler-icon"></span></button>
        <div class="c-header-nav mr-4">
            <ol class="breadcrumb border-0 m-0">
                <li class="breadcrumb-item"><a href="/dashboard"><i class="c-icon fas fa-home text-dark"></i></a></li>
                <?php $segments = ''; ?>
                <?php for($i = 1; $i <= count(Request::segments()); $i++): ?>
                    <?php $segments .= '/'. Request::segment($i); ?>
                    <?php if($i < count(Request::segments())): ?>
                        <li class="breadcrumb-item"><?php echo e(strtoupper(Request::segment($i))); ?></li>
                    <?php else: ?>
                        <li class="breadcrumb-item active"><?php echo e(strtoupper(Request::segment($i))); ?></li>
                    <?php endif; ?>
                <?php endfor; ?>
            </ol>
        </div>
        <ul class="c-header-nav ml-auto mr-4">
            <li class="c-header-nav-item d-md-down-none mx-2">
                Olá, <?php echo e(Auth::user()->name); ?>!
            </li>
            <li class="c-header-nav-item dropdown">
                <a class="c-header-nav-link" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                    <div class="c-avatar">
                        <i class="c-icon c-icon-2xl far fa-user-circle"></i>
                    </div>
                </a>
                <div class="dropdown-menu dropdown-menu-right pt-0">
                    <div class="dropdown-header bg-light py-2"><strong>Configurações</strong></div>
                    <a class="dropdown-item" href="<?php echo e(route('profile.showProfile')); ?>">
                        <i class="far fa-address-card mr-2"></i> <span>Perfil</span>
                    </a>
                    <a class="dropdown-item" href="<?php echo e(route('users.indexChangePassword')); ?>">
                        <i class="fas fa-pen mr-2"></i> <span>Alterar senha</span>
                    </a>
                    <form action="<?php echo e(url('/logout')); ?>" class="" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="dropdown-item btn"><i class="fas fa-sign-out-alt mr-2"></i> <span>Sair</span></button>
                    </form>
                </div>
            </li>
        </ul>
    </header>
<?php /**PATH C:\xampp\php\www\maistek\resources\views/base/shared/header.blade.php ENDPATH**/ ?>